:- module(cr_sig, [op(1199, fx, [(type), (pred)]),
		   op(1110, xfy, (-->))]).
