Per eseguire l'algoritmo di Type Checking / Reconstruction, usare:

---> rload(<name>).		verifica e caricamento del file <name>.pl
---> rload([<name>,..,<name>]).	verifica e caricamento della lista di file <name>.pl,...
---> gload(....).		rload + caricamento dell'ambiente di ispezione e generazione
---> genh                       help per l'AMBIENTE DI GENERAZIONE
